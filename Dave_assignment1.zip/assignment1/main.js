alert('test');

(function($) {


$('div#gallery').on('click', 'a.like', function() {

console('worked');
});



})(jQuery);